import React, { useState } from 'react';
import './PageOne.css';
import { useNavigate } from 'react-router-dom';

const PageOne = () => {
  const navigate = useNavigate();

  const handleRedirect = () => {
    navigate('/Dados');
  };

  const [login, setLogin] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = () => {
    console.log('Login:', login);
    console.log('Password:', password);
  };

  return (
    <div className="container">
      <div className="content">
        <div className="form">
          <input
            type="text"
            placeholder="Digite seu login"
            style={{width: '150px', height: '34px'}}
            className='loginContainerInput'
            value={login}
            onChange={(e) => setLogin(e.target.value)}
          />
          <input
            type="password"
            placeholder="Digite sua senha"
            style={{width: '150px', height: '34px',}}
            className='loginContainerInput'
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />
          <button className="login-button" onClick={handleRedirect}>
            Login
          </button>
        </div>
      </div>
      <footer className="footer">
        Desenvolvido por <span className="author">Pixuleco06</span>
      </footer>
    </div>
  );
};

export default PageOne;
