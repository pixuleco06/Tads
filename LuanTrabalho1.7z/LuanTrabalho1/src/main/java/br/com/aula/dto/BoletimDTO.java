package br.com.aula.dto;

public class BoletimDTO {
    private String nomeEstudante;
    private String nomeCurso;
    private String nomeDisciplina;
    private double nota;
    private String status;

    public BoletimDTO(String nomeEstudante, String nomeCurso, String nomeDisciplina, double nota, String status) {
        this.nomeEstudante = nomeEstudante;
        this.nomeCurso = nomeCurso;
        this.nomeDisciplina = nomeDisciplina;
        this.nota = nota;
        this.status = status;
    }

    public String getNomeEstudante() {
        return nomeEstudante;
    }

    public void setNomeEstudante(String nomeEstudante) {
        this.nomeEstudante = nomeEstudante;
    }

    public String getNomeCurso() {
        return nomeCurso;
    }

    public void setNomeCurso(String nomeCurso) {
        this.nomeCurso = nomeCurso;
    }

    public String getNomeDisciplina() {
        return nomeDisciplina;
    }

    public void setNomeDisciplina(String nomeDisciplina) {
        this.nomeDisciplina = nomeDisciplina;
    }

    public double getNota() {
        return nota;
    }

    public void setNota(double nota) {
        this.nota = nota;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
