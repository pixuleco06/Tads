import React from 'react';
import { Link } from 'react-router-dom';

const DigimonCard = ({ digimon, setSelectedDigimon }) => {
  const handleMoreDetails = () => {
    window.open(`/detalhes/${digimon.name}`, '_blank');
  };

  return (
    <div className="digimonCard">
      <img src={digimon.img} alt={digimon.name} />
      <h2>{digimon.name}</h2>
      <p>Level: {digimon.level}</p>
      <button className="closeButton" onClick={() => setSelectedDigimon(null)}>
        Fechar
      </button>
      <Link to={`/detalhes/${digimon.name}`}>
        <button className="moreDetailsBotton">Mais detalhes</button>
      </Link>
    </div>
  );
};

export default DigimonCard;
