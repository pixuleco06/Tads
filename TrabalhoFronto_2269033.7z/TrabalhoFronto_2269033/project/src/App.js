import logo from './logo.svg';
import './App.css';
import PageOne from './pages/PageOne';
import { RouterProvider, createBrowserRouter } from 'react-router-dom';
import DadosDigimon from './pages/DadosDigimon';
import DetalhesDigimon from './Components/DetalhesDigimon';

function App() {
  const routes = createBrowserRouter([
    {
      path: '/',
      element: <PageOne />,
    },
    {
      path: '/Dados',
      element: <DadosDigimon />,
    },
    {
      path: '/detalhes/:name',
      element: <DetalhesDigimon />,
    },
  ]);

  return (
    <div className="App">
      <h1>
        <RouterProvider router={routes} />
      </h1>
    </div>
  );
}

export default App;
