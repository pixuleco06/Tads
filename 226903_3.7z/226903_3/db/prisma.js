const prisma = require("@prisma/client");

module.exports = new prisma.PrismaClient();