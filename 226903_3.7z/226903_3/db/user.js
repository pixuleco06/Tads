const prisma = require("./prisma");

const findUserEmail = (email)=>{
    return prisma.user.findFirst({
        where:{email}
    });
}

const createUser = (user) =>{
    return prisma.user.create({
        data: user
    }); 
};


module.exports= {
    findUserEmail,
    createUser
}
