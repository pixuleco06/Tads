//package br.com.aula.service;
//
//import br.com.aula.repository.VendaRepository;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Service;
//
//import java.util.List;
//
//@Service
//public class VendaService {
//    @Autowired
//    private VendaRepository repository;
//
//    public List<Venda> listaVenda(){
//        return repository.findAll();
//    }
//}
