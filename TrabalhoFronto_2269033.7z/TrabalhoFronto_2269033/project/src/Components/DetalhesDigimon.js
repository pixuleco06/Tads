import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useParams } from 'react-router-dom';
import './DetalhesDigimon.css';

const DetalhesDigimon = () => {
  const { name } = useParams();
  const [digimon, setDigimon] = useState(null);

  useEffect(() => {
    async function fetchDigimonDetails() {
      try {
        const response = await axios.get(`https://digimon-api.vercel.app/api/digimon/name/${name}`);
        setDigimon(response.data[0]);
      } catch (error) {
        console.log(error);
      }
    }

    fetchDigimonDetails();
  }, [name]);

  if (!digimon) {
    return <div>Loading...</div>;
  }

  return (
    <div className='detalhesContainer'>
      <h2>Name: {digimon.name}</h2>
      <img src={digimon.img} alt={digimon.name} />
      <p>Level: {digimon.level}</p>
      <button className='detailsButton'>Adquirir</button>
      <button className='detailsButton'>Devolver</button>
    </div>
  );
};

export default DetalhesDigimon;
