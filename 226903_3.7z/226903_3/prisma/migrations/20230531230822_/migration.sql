-- AlterTable
ALTER TABLE `receita` MODIFY `tempo` VARCHAR(191) NOT NULL;
